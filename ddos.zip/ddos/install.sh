sudo apt -y update
yum -y update
sudo apt -y install screen nodejs
yum -y install screen nodejs
npm i randomstring
npm i request
pip3 install -r requirements.txt
pip install -r requirements.txt
python3 abc.py
